<?php
    header("location: patientProfileForm.php");
?>